package com.cg.jpastart.entities;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="student")
public class Student implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	private String Student_Name;
	private String Address;
	private String city;
	private int CS_Marks;
	private int Physics_Marks; 	
	private int Total;
	public void getsum(int cS_Marks,int physics_Marks)
	{
		Total=cS_Marks+physics_Marks;
	}
	
	public void setStudent_Name(String student_Name) {
		Student_Name = student_Name;
	}
	public void setAddress(String student_Address) {
		Address = student_Address;
	}
	public void setcity(String student_city) {
		city = student_city;
	}
	public void setCS_Marks(int cS_Marks) {
		CS_Marks = cS_Marks;
	}
	public void setPhysics_Marks(int physics_Marks) {
		Physics_Marks = physics_Marks;
	}
	public void setTotal(int total) {
		Total = total;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getStudent_Name() {
		return Student_Name;
	}
	public String getAddress() {
		return Address;
	}
	public String getcity() {
		return city;
	}
	public int getCS_Marks() {
		return CS_Marks;
	}
	public int getPhysics_Marks() {
		return Physics_Marks;
	}
	public int getTotal() {
		return Total;
	}
	
	
	
	
	
}
