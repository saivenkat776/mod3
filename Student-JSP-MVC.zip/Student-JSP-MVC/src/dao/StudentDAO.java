package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.nag.StudentBean;

//import com.ram.beans.BookBean;
//import com.ram.dao.BookDB;

public class StudentDAO 
{
	
	
  public static int addStudent(StudentBean bean)
  {
	  Connection con = null;
	  PreparedStatement pstmt = null;
	  try
	  {
		  /* Class.forName("com.mysql.jdbc.Driver");
	         con = DriverManager.getConnection(
	         "jdbc:mysql://localhost:3309/accdb","root","root"); 
	     */
		  con=StudentDB.getConnection(); 
		  
		  String ins_str = 
			  "insert into student values(?,?,?,?,?,?)";
		  
		  pstmt = con.prepareStatement(ins_str);
		  
		  pstmt.setString(1,bean.getStudent_name());
		  pstmt.setString(2,bean.getAddress());
		  pstmt.setString(3,bean.getCity());
		  pstmt.setInt(4,bean.getCs_marks());
		  pstmt.setInt(5,bean.getPhysics_marks());
		  pstmt.setInt(6,bean.getTotal());
		 
		  
		  
		  int updateCount = pstmt.executeUpdate();
		  
		  con.close();
		  
		  return updateCount;
		  
		  
	  }
	  catch(Exception ex)
	  {
		  System.out.println(ex.toString());
		  return 0;
	  }
	  
  }
}
  
  
 /* // Below method, Search by ID Module.    
  public ArrayList getBookDetailsById(int bookId)
			throws Exception
			{
				Connection con = null;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				
				con = BookDB.getConnection();
				
		    String sel_str ="Select title,price from book where bookId=?";
				  
				  
				  pstmt = con.prepareStatement(sel_str);
				  pstmt.setInt(1,bookId);
				  rs = pstmt.executeQuery();
				  
				  ArrayList result = new ArrayList();
				  if(rs.next())
				  {
					  result.add(rs.getString(1));
					  result.add(rs.getString(2));
					  
				  }
				  else
				  {
					  result.add("Invalid Id");
				  }
				  return result;
				
			}
}*/